export class CustomError {
  constructor(readonly code: number, readonly message: string) {}
}
