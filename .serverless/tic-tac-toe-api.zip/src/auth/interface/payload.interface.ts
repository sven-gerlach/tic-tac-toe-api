export interface PayloadInterface {
  email: string;
  _id: string;
}
