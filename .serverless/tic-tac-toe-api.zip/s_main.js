
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'svengerlach',
  applicationName: 'tic-tac-toe-api',
  appUid: 'QGRWv5pqkBkQqjd7JD',
  orgUid: '37cd322f-5879-48e3-aa4d-560e42bb5148',
  deploymentUid: '761730fb-5620-44af-9475-653d22496599',
  serviceName: 'tic-tac-toe-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tic-tac-toe-api-prod-main', timeout: 6 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}